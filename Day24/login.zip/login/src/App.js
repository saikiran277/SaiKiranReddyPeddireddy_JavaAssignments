import React from 'react';
import './App.css'
import {  Routes,  Route ,Link} from 'react-router-dom';
import Login from './components/login';
import Signup from './components/signup';
import Contact from './components/contact';

export default function App() {
  return (
      <div>
	<nav>
          <ul>
            <li>
              <Link to="/login">Log-In</Link>
            </li>
            <li>
              <Link to="/signup">Sign-Up</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </nav>
        <hr />
        <Routes>
          <Route exact path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/contact/:id" element={<Contact/>}/> 
        </Routes>
      </div>
  );
}