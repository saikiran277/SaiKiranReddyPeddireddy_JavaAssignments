import './css/log_sign.css'
import React, {useState} from 'react';
function Signup() {  //state
const [inputField , setInputField] = useState({
  first_name: '',
  last_name: '',
  gmail: '',
  user_name: '',
  mob: '',
  password: ''

})
const inputsHandler = (e) =>{
    const { name, value } = e.target;
   setInputField((prevState) => ({...prevState,[name]: value,}));
}
const submitButton = () =>{
    alert(inputField.first_name+ " "+inputField.last_name+ " "+
      inputField.email1+ " "+inputField.user_name+ " "+
      inputField.mob+ " "+inputField.pass
    )
    console.log(inputField.first_name+ " "+inputField.last_name+ " "+
      inputField.email1+ " "+inputField.user_name+ " "+
      inputField.mob+ " "+inputField.pass
    )
}
 return (
     <div id="log_div1">
      <h1 > SignUp Form</h1>  
         
         <input id="log1"
        type="text" 
        name="first_name" 
        onChange={inputsHandler} 
        placeholder="First Name" 
        value={inputField.first_name}/>
       <br/>
        <input id="log1"
        type="text" 
        name="last_name" 
        onChange={inputsHandler} 
        placeholder="Last Name" 
        value={inputField.last_name}/>
        <br/>
        <input id="log1"
        type="text" 
        name="email1" 
        onChange={inputsHandler} 
        placeholder="email" 
        value={inputField.email1}/>
       <br/>
        <input id="log1"
        type="text" 
        name="user_name" 
        onChange={inputsHandler} 
        placeholder="UserName" 
        value={inputField.user_name}/>
        <br/>
        <input id="log1"
        type="number" 
        name="mob" 
        onChange={inputsHandler} 
        placeholder="Mobile Number" 
        value={inputField.mob}/>
       <br/>
        <input id="log1"
        type="text" 
        name="pass" 
        onChange={inputsHandler} 
        placeholder="Password" 
        value={inputField.pass}/>
        <br/>

        <br/>
        <button id="lodbut" onClick={submitButton}>SignUp</button>
        <div>
        FIRSNAME: {inputField.first_name}<br/>
        LASTNAME : {inputField.last_name}<br/>
        EMAIL: {inputField.email1}<br/>
        USERNAME : {inputField.user_name}<br/>
        MOBILE: {inputField.mob}<br/>
        PASSWORD : {inputField.pass}<br/>
        </div>

    </div>
)
}

export default Signup;
