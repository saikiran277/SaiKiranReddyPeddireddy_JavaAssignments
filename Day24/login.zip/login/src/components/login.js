import './css/log_sign.css'
import React, {useState} from 'react';
function Login() {  //state
const [inputField , setInputField] = useState({
    user_name: '',
    password: ''
})
const inputsHandler = (e) =>{
    const { name, value } = e.target;
   setInputField((prevState) => ({...prevState,[name]: value,}));
}
const submitButton = () =>{
    alert(inputField.user_name+ " "+inputField.passw)
    console.log(inputField.user_name+ " "+inputField.passw)
}
 return (
     <div id="log_div">
      <h1 > Login Form</h1>  
         
         <input id="log"
        type="text" 
        name="user_name" 
        onChange={inputsHandler} 
        placeholder=" UserName" 
        value={inputField.user_name}/>
       <br/>
        <input id="log"
        type="text" 
        name="passw "
        onChange={inputsHandler} 
        placeholder="Password" 
        value={inputField.passw}/>
        <br/>

        <br/>
        <button id="lodbut" onClick={submitButton}>Submit Now</button>
        <div>
        UserName: {inputField.user_name}
        Password : {inputField.passw}
        </div>

    </div>
)
}

export default Login;
